import fitz  # PyMuPDF
import prompt,json,words_to_list
import report_generate

# Function to extract text from PDF
def extract_text_from_pdf(pdf_path):
    with fitz.open(pdf_path) as doc:
        text = ""
        for page in doc:
            text += page.get_text()
    return text

job_description=input("Enter the job description: ")
resume_text = extract_text_from_pdf('resume.pdf')

response=prompt.chatgpt_1(job_description,resume_text)
print(response)
#to extract the json alone from the chatgpt reply
json_data=words_to_list.lis_1(response)

#to generate resume analysis report and to get back the score
rep,score=report_generate.report_generate(json_data)

print(rep)

print("score: ",score)
