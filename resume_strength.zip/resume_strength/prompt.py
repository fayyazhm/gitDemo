from openai import OpenAI

client = OpenAI(api_key='sk-proj-8yaDf3NdpdHxFKeFqSb0T3BlbkFJDyEhWpCyY0sKFAfsCVzu')

def chatgpt(text):
    prompt = f"""
    I have a text, and I need to extract all the technical terms from it. The text is:

    "{text}"

    Can you list all the technical terms and relevant soft skills from this text as a python list and no other words just plain list?
    """
    response = client.chat.completions.create(model="gpt-4",
    messages=[{"role": "system", "content": prompt}])

    return response.choices[0].message.content.strip()

def chatgpt_1(job_description,resume_description):
    prompt = f"""
    I have a Job Description and Resume Description, and I need you to compare the Job Desciption and Resume Description and give the output as a valid json with keys as matches,gaps ie skills mentioned in job_description but not available in resume_description,score out of 100,name and values for the respective key should be list.The Job Description and Resume Description is:

    "{job_description}","{resume_description}"

    give the output as a valid json with keys as matches,gaps,score,name and values for the respective key should be list.

    """
    response = client.chat.completions.create(model="gpt-4",
    messages=[{"role": "system", "content": prompt}])

    return response.choices[0].message.content.strip()


def chatgpt_2(resume_description):
    prompt = f"""
    I have a Resume Description, and I need you to create a list alone with the 6 technical terms alone that the resume_description has. The Resume Description is:
    "{resume_description}"

    give the output as a just as a list alone with the 6 technical terms alone the result should s strictly  have no other words other than the list.

    """
    response = client.chat.completions.create(model="gpt-4",
    messages=[{"role": "system", "content": prompt}])

    return response.choices[0].message.content.strip()

def chatgpt_3(technical_word):
    prompt = f"""
    I have a technical word, and I need you to create a valid json with four keys as difficult level ie easy,medium,hard,expert and based on that difficulty level,the respective values should be a list having 10 questions each:
    "{technical_word}"

    give the output as a valid json alone as described above nothin more nothing less.
    """
    response = client.chat.completions.create(model="gpt-4",
    messages=[{"role": "system", "content": prompt}])

    return response.choices[0].message.content.strip()

def chatgpt_4(job_description):
    prompt = f"""
    I have a job Description, and I need you to create a json with two keys one keys is "skills" and the value for skills is a list having six technical skills the other key is job_descirption and the value is a string descirbing about the job in few sentenses .The Job Description is:
    "{job_description}"

    give the output as a requested json alone nothing else nothing more.

    """
    response = client.chat.completions.create(model="gpt-4",messages=[{"role": "system", "content": prompt}])

    return response.choices[0].message.content.strip()


def chatgpt_5(job_description):
    prompt = f"""
    I have a job Description, and I need you to create a list for example like this ["vue","flask","physics"] alone with 6 technical "skills" nothing else nothing more.The Job Description is:
    "{job_description}"

    give the output as above requested nothing else nothing more.

    """
    response = client.chat.completions.create(model="gpt-4",messages=[{"role": "system", "content": prompt}])

    return response.choices[0].message.content.strip()

def chatgpt_6(job_description):
    prompt = f"""
    I have a job Description, and I need you to give me a string describing about the job description in few sentenses.The Job Description is:
    "{job_description}"

    give the output as above requested nothing else nothing more.

    """
    response = client.chat.completions.create(model="gpt-4",messages=[{"role": "system", "content": prompt}])

    return response.choices[0].message.content.strip()

