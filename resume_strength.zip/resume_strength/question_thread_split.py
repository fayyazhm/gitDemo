from fastapi import FastAPI, File, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import os
from concurrent.futures import ThreadPoolExecutor
import fitz  # PyMuPDF
from docx import Document
from pptx import Presentation
import words_to_list
import prompt

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods
    allow_headers=["*"],  # Allow all headers
)

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

def extract_text_from_pdf(pdf_path):
    with fitz.open(pdf_path) as doc:
        text = ""
        for page in doc:
            text += page.get_text()
    return text

def extract_text_from_docx(docx_path):
    doc = Document(docx_path)
    return "\n".join([para.text for para in doc.paragraphs])

def extract_text_from_pptx(pptx_path):
    presentation = Presentation(pptx_path)
    text = ""
    for slide in presentation.slides:
        for shape in slide.shapes:
            if hasattr(shape, "text"):
                text += shape.text + "\n"
    return text

@app.post("/upload/jd")
async def upload_file(file: UploadFile = File(...)):
    try:
        file_location = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_location, "wb+") as file_object:
            file_object.write(file.file.read())
        
        if file.filename.endswith(".pdf"):
            extracted_text = extract_text_from_pdf(file_location)
        elif file.filename.endswith(".docx"):
            extracted_text = extract_text_from_docx(file_location)
        elif file.filename.endswith(".pptx"):
            extracted_text = extract_text_from_pptx(file_location)
        else:
            return JSONResponse(content={"message": "Unsupported file type"}, status_code=400)
        
        def extract_skills():
            skills_text = prompt.chatgpt_5(extracted_text)
            print(skills_text)
            return words_to_list.lis(skills_text)

        def extract_job_description():
            tex=prompt.chatgpt_6(extracted_text)
            print(tex)
            return tex
        
        with ThreadPoolExecutor() as executor:
            skills_future = executor.submit(extract_skills)
            job_description_future = executor.submit(extract_job_description)

            skills_list = skills_future.result()
            job_description_text = job_description_future.result()
        skills_json = {"skills": skills_list, "job_description": job_description_text}

        return JSONResponse(content={"message": "File uploaded and text extracted successfully", "skills": skills_json}, status_code=200)
    except Exception as e:
        return JSONResponse(content={"message": "Error uploading file", "error": str(e)}, status_code=500)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, port=8000)
