from fastapi import FastAPI
import words_to_list
import fitz  # PyMuPDF
import prompt,words_to_list


# app = FastAPI()

# @app.get("/")
# async def hello():
#     return {"message": "Hello, world!"}

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run(app,port=8000)

# Function to extract text from PDF
def extract_text_from_pdf(pdf_path):
    with fitz.open(pdf_path) as doc:
        text = ""
        for page in doc:
            text += page.get_text()
    return text

resume_text = extract_text_from_pdf('resume.pdf')


response=prompt.chatgpt_2(resume_text)
skills=words_to_list.lis(response)

print(skills)

result={}

count=0
for i in skills:
    count+=1
    if i not in result and i != "":
        result[i]={}
    if i!="":
        res=prompt.chatgpt_3(i)
        questions=words_to_list.lis_1(res)
        result[i]=questions
        question_list=words_to_list.lis_3(result)
        words_to_list.list_excel(question_list)
        question_list=[]
        result={}
        print(count," skill completed added to excel file")
    if count==4:
        break
print("completed adding 6 skill questions to excel file")
