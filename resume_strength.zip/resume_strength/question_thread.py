from fastapi import FastAPI
import words_to_list
import fitz  # PyMuPDF
import prompt
import concurrent.futures

app = FastAPI()



def extract_text_from_pdf(pdf_path):
    with fitz.open(pdf_path) as doc:
        text = ""
        for page in doc:
            text += page.get_text()
    return text

# Function to process each skill
def process_skill(skill):
    if skill:
        res = prompt.chatgpt_3(skill)
        questions = words_to_list.lis_1(res)
        return skill, questions
    return None

@app.get("/question")
async def hello():
    # Load resume text and generate skills
    resume_text = extract_text_from_pdf('resume.pdf')
    response = prompt.chatgpt_2(resume_text)
    skills = words_to_list.lis(response)
    print(skills)
    result = {}
    count = 0

    # Create a thread pool
    with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
        futures = {}
        for skill in skills[:6]:
            future = executor.submit(process_skill, skill)
            print("hello")
            futures[future] = skill

        for future in concurrent.futures.as_completed(futures):
            skill = futures[future]
            try:
                skill, questions = future.result()
                result[skill] = questions
                question_list = words_to_list.lis_3(result)
                words_to_list.list_excel(question_list)
                question_list = []
                result = {}
                count += 1
                print(f"{count} skill completed added to excel file")
            except Exception as exc:
                print(f"Skill {skill} generated an exception: {exc}")

    print("Completed adding 6 skill questions to excel file")
    return {"message": "the questions are added to excel!"}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app,port=8000)


