import fitz  # PyMuPDF
import re
import matplotlib.pyplot as plt
import report_generate

# Function to extract text from PDF
def extract_text_from_pdf(pdf_path):
    with fitz.open(pdf_path) as doc:
        text = ""
        for page in doc:
            text += page.get_text()
    return text

# Function to extract key terms from a text, excluding stop words
def extract_key_terms(text, stop_words):
    words = re.findall(r'\b\w+\b', text.lower())
    return [word.lower() for word in words if word not in stop_words]


# List of common stop words
stop_words = set([
    'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', 'aren\'t', 'as', 'at',
    'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by', 'can\'t', 'cannot', 'could',
    'couldn\'t', 'did', 'didn\'t', 'do', 'does', 'doesn\'t', 'doing', 'don\'t', 'down', 'during', 'each', 'few', 'for',
    'from', 'further', 'had', 'hadn\'t', 'has', 'hasn\'t', 'have', 'haven\'t', 'having', 'he', 'he\'d', 'he\'ll', 'he\'s',
    'her', 'here', 'here\'s', 'hers', 'herself', 'him', 'himself', 'his', 'how', 'how\'s', 'i', 'i\'d', 'i\'ll', 'i\'m',
    'i\'ve', 'if', 'in', 'into', 'is', 'isn\'t', 'it', 'it\'s', 'its', 'itself', 'let\'s', 'me', 'more', 'most', 'mustn\'t',
    'my', 'myself', 'no', 'nor', 'not', 'of', 'off', 'on', 'once', 'only', 'or', 'other', 'ought', 'our', 'ours',
    'ourselves', 'out', 'over', 'own', 'same', 'shan\'t', 'she', 'she\'d', 'she\'ll', 'she\'s', 'should', 'shouldn\'t',
    'so', 'some', 'such', 'than', 'that', 'that\'s', 'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there',
    'there\'s', 'these', 'they', 'they\'d', 'they\'ll', 'they\'re', 'they\'ve', 'this', 'those', 'through', 'to', 'too',
    'under', 'until', 'up', 'very', 'was', 'wasn\'t', 'we', 'we\'d', 'we\'ll', 'we\'re', 'we\'ve', 'were', 'weren\'t',
    'what', 'what\'s', 'when', 'when\'s', 'where', 'where\'s', 'which', 'while', 'who', 'who\'s', 'whom', 'why', 'why\'s',
    'with', 'won\'t', 'would', 'wouldn\'t', 'you', 'you\'d', 'you\'ll', 'you\'re', 'you\'ve', 'your', 'yours', 'yourself',
    'yourselves','for',"a", "an", "the",
    "I", "you", "he", "she", "it", "we", "they", 
    "me", "him", "her", "us", "them", 
    "my", "your", "his", "her", "its", "our", "their",
    "mine", "yours", "hers", "ours", "theirs",
    "and", "but", "or", "nor", "for", "yet", "so", 
    "although", "because", "since", "unless", "if",
    "in", "on", "at", "by", "for", "with", "about", "against",
    "between", "among", "through", "during", "before", 
    "after", "above", "below", "to", "from", "up", "down", 
    "over", "under",
    "be", "am", "is", "are", "was", "were", "being", "been",
    "have", "has", "had",
    "do", "does", "did",
    "will", "shall", "would", "should", 
    "can", "could", "may", "might", "must", "ought to",
    "this", "that", "these", "those", 
    "some", "any", "no", 
    "many", "much", "each", "every", 
    "either", "neither",
    "not", "to"
])

# Sample job description

# Extract key terms from job description
name=input("Enter the name of the applicant: ")
job_description_input = input("Enter the keywords for the job description: ")
keywords = [word.lower() for word in re.split(r'[\s,]+', job_description_input.strip())]
job_terms = set(map(str.strip, keywords))


print("job_terms",job_terms)
# Extract text from the resume PDF
resume_text = extract_text_from_pdf('resume.pdf')
resume_terms = set(extract_key_terms(resume_text, stop_words))

# Find matches and gaps
matches = job_terms.intersection(resume_terms)
gaps = job_terms.difference(resume_terms)

score=(len(matches)/(len(matches)+len(gaps)))*100
score_round = round(score, 2)
# Print results
print("-----------------------------------------------------------------------------")
print("Matches:", matches)
print("-----------------------------------------------------------------------------")
print("Gaps:", gaps)
print("Score",f'{score_round} %')
# Calculate sizes for the pie chart
num_matches = len(matches)
num_gaps = len(gaps)

# Define the labels, sizes, and colors for the pie chart
labels = 'Matches', 'No Matches'
sizes = [num_matches, num_gaps]
colors = ['#ff9999','#66b3ff']
explode = (0.1, 0)  # explode the 1st slice (Matches)

# Create the pie chart
fig1, ax1 = plt.subplots()
ax1.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True, startangle=140)

# Equal aspect ratio ensures that pie is drawn as a circle
ax1.axis('equal')

# Add title
plt.title("Resume vs Job Description Match")

# Display the pie chart
plt.show()

json_data={"matches":[],"gaps":[],"score":[],"name":[]}
for i in matches:
    json_data["matches"].append(i)
for i in gaps:
    json_data["gaps"].append(i)
json_data["score"]=score_round
json_data["name"]=name

print(report_generate.report_generate(json_data))