import json
import pdfkit,os
from jinja2 import Environment, FileSystemLoader




def report_generate(json_data):
    # Load HTML template using Jinja2
    env = Environment(loader=FileSystemLoader('.'))
    template = env.get_template('report.html')

    # Render HTML with data
    if isinstance(json_data['name'], list):
        name = json_data['name'][0]
    else:
        name=json_data['name']

    if isinstance(json_data['score'], list):
        score = json_data['score'][0]
    else:
        score=json_data['score']

    score1=round(((len(json_data["matches"])/(len(json_data["gaps"])+len(json_data["matches"])))*100),2)    
    print(score1)
    print("chatgpt: ",score)
    score=min(int(score),score1)
    html_content = template.render(data=json_data,name=name,score=score)


    output_folder = "reports"
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    pdf_output = os.path.join(output_folder, "resume_analysis_report.pdf")
    pdfkit.from_string(html_content, pdf_output)

    return(f"PDF generated and saved as {pdf_output}",score)