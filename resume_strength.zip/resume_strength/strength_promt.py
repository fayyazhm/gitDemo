import fitz  # PyMuPDF
import re
import matplotlib.pyplot as plt
import prompt,words_to_list


# Function to extract text from PDF
def extract_text_from_pdf(pdf_path):
    with fitz.open(pdf_path) as doc:
        text = ""
        for page in doc:
            text += page.get_text()
    return text

job_description=input("Enterthe job description: ")
resume_text = extract_text_from_pdf('resume.pdf')

jd=prompt.chatgpt(job_description)
rd=prompt.chatgpt(resume_text)
job_terms=set(words_to_list.lis(jd))
resume_terms = set(words_to_list.lis(rd))

print(job_terms)
print(resume_terms)

# Find matches and gaps
matches = job_terms.intersection(resume_terms)
gaps = job_terms.difference(resume_terms)

score=(len(matches)/(len(matches)+len(gaps)))*100
score_round = round(score, 2)


# Print results
print("-----------------------------------------------------------------------------")
print("Matches:", matches)
print("-----------------------------------------------------------------------------")
print("Gaps:", gaps)
print("Score",f'{score_round} %')

# Calculate sizes for the pie chart
num_matches = len(matches)
num_gaps = len(gaps)

# Define the labels, sizes, and colors for the pie chart
labels = 'Matches', 'No Matches'
sizes = [num_matches, num_gaps]
colors = ['#ff9999','#66b3ff']
explode = (0.1, 0)  # explode the 1st slice (Matches)

# Create the pie chart
fig1, ax1 = plt.subplots()
ax1.pie(sizes, explode=explode, labels=labels, colors=colors,
        autopct='%1.1f%%', shadow=True, startangle=140)

# Equal aspect ratio ensures that pie is drawn as a circle
ax1.axis('equal')

# Add title
plt.title("Resume vs Job Description Match")

# Display the pie chart
plt
 