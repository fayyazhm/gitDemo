import re,json,os
import openpyxl
from openpyxl import Workbook

def lis(text):
    substring_pattern = r'\[(.*?)\]'
    matches = re.findall(substring_pattern, text)
    words_list=matches[0].split(",")
    cleaned_words=[]
    for word in words_list:
        w=(re.sub(r"^[ ]*['\"]|['\"]$", '', word))
        wor=w.lower()
        cleaned_words.append(wor)
    return(cleaned_words)

def lis_1(text):
    substring_pattern=r"\{.*?\}"
    words_list=re.findall(substring_pattern, text,re.DOTALL)
    cleaned_list = [re.sub(r'\s+', ' ', word.replace('\n', '').replace('\r', '').strip()).replace("\\'", "'") for word in words_list][0]
    json_data=json.loads(cleaned_list)
    return(json_data)

def lis_3(text):
    results=[]

    for i in text:
        for j in text[i]:
            for k in text[i][j]:
                results.append([i,j,k])
    return results


# def list_excel(data):
#     wb=openpyxl.load_workbook('./result.xlsx') 
#     ws=wb.active
#     next_row=ws.max_row+1
#     for row_data in data:
#         for col_num, value in enumerate(row_data, start=1):
#             ws.cell(row=next_row, column=col_num, value=value)
#         next_row += 1  

#     wb.save('./result.xlsx')


# # did={'quality engineering': {'easy': ['What is Quality Engineering?', 'Can you name a key component of Quality Engineering?', 'What is the first step in Quality Engineering?', 'What is the goal of Quality Engineering?', 'What differentiates Quality Engineering from other engineering branches?', 'Who can be a Quality Engineer?', 'What background is necessary for Quality Engineering?', 'How is Quality Engineering related to production?', 'Name a field where Quality Engineering is implemented.', 'What is the importance of Quality Engineering in software development?'], 'medium': ['What skills does a Quality Engineer require?', 'What kind of tools or software does a Quality Engineer use?', 'How does Quality Engineering affect the final product?', 'What is the role of Quality Engineering in risk management?', 'What are the complexities associated with Quality Engineering?', 'Describe how Quality Engineering involves process control.', 'How can Quality Engineering resolve defects in a product?', 'What strategies are involved in Quality Engineering?', 'How is Quality Engineering involved in business strategy?', 'What are some obstacles one might face in Quality Engineering?'], 'hard': ['What are the detailed stages in the Quality Engineering process?', 'How does Quality Engineering integrate with other departments in a company?', 'Explain a situation where Quality Engineering saved a project from failure.', 'What statistical methodologies are used in Quality Engineering?', 'How can advancements in technology enhance Quality Engineering?', 'Explain the impact of Quality Engineering on customer satisfaction.', 'What kind of project requires close attention from a Quality Engineer?', 'How does Quality Engineering contribute to productivity?', 'What kind of metrics are used to evaluate success in Quality Engineering?', 'Please explain a complex Quality Engineering concept.'], 'expert': ["How can Quality Engineering guide a company's direction in the long term?", 'Describe how Quality Engineering evolves with industry trends.', 'What challenges are there in implementing Quality Engineering in a new product?', 'What is the role of AI in Quality Engineering?', "Discuss how Quality Engineering contributes to a company's reputation.", 'Describe how you would troubleshoot a major issue as a Quality Engineer.', 'How can Quality Engineering be a game-changer in competitive industries?', 'What is the role of Quality Engineering in sustainable development?', 'How does Quality Engineering facilitate innovation in a company?', 'Discuss the future of Quality Engineering given emerging technologies.']}}
# # val=lis_3(did)
# # for i in val:
# #     print(i)

def list_excel(data):
    file_path = './result.xlsx'
    
    # Check if the file exists, if not, create a new workbook
    if not os.path.exists(file_path):
        wb = Workbook()
        wb.save(file_path)
    
    # Load the workbook
    wb = openpyxl.load_workbook(file_path)
    ws = wb.active
    
    # Find the next available row
    next_row = ws.max_row + 1 if ws.max_row > 1 else 1
    
    # Write data to the Excel file
    for row_data in data:
        for col_num, value in enumerate(row_data, start=1):
            ws.cell(row=next_row, column=col_num, value=value)
        next_row += 1
    
    # Save the workbook
    wb.save(file_path)
    wb.close()



